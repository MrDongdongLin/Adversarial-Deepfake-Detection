:mod:`foolbox.v1.adversarial`
====================================

.. automodule:: foolbox.v1.adversarial

.. autoclass:: Adversarial
   :members:
