:mod:`foolbox.utils`
==============================

.. automodule:: foolbox.utils

.. autofunction:: softmax
.. autofunction:: crossentropy
.. autofunction:: batch_crossentropy
.. autofunction:: binarize
.. autofunction:: imagenet_example
.. autofunction:: samples
.. autofunction:: onehot_like
