Score-based attacks
-----------------

.. currentmodule:: foolbox.attacks

.. autoclass:: SinglePixelAttack
   :members:
   :special-members:

.. autoclass:: LocalSearchAttack
   :members:
   :special-members:

.. autoclass:: ApproximateLBFGSAttack
   :members:
   :special-members:
