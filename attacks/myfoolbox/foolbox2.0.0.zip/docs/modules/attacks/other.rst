Other attacks
-------------

.. currentmodule:: foolbox.attacks

.. autoclass:: BinarizationRefinementAttack
   :members:
   :special-members:

.. autoclass:: PrecomputedAdversarialsAttack
   :members:
   :special-members:

.. autoclass:: InversionAttack
   :members:
   :special-members:
