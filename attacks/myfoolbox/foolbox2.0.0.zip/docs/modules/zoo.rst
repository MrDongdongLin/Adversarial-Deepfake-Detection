:mod:`foolbox.zoo`
=================================

.. automodule:: foolbox.zoo


Get Model
----------------

.. autofunction:: get_model



Fetch Weights
----------------

.. autofunction:: fetch_weights
