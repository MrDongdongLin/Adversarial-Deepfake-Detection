:mod:`foolbox.adversarial`
====================================

.. automodule:: foolbox.adversarial

.. autoclass:: Adversarial
   :members:
   :inherited-members:
